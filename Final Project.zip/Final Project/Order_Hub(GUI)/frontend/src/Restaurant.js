import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { useNavigate, useParams } from 'react-router-dom'; // Import useParams

const Restaurant = () => {
    const navigate = useNavigate();
    const { customerID } = useParams(); // Extract customerID from URL
    const [restaurants, setRestaurants] = useState([]);

    useEffect(() => {
        const fetchRestaurants = async () => {
            try {
                const response = await axios.get('http://localhost:3000/api/restaurants');
                setRestaurants(response.data);
            } catch (error) {
                console.error('Error fetching restaurants:', error);
            }
        };
        fetchRestaurants();
    }, []);

    const handleRestaurantClick = (restaurantId) => {
        navigate(`/menu/${customerID}/${restaurantId}`); // Use customerID from URL
    };

    return (
        <Container>
            <h2 className="my-4 text-center">Explore Restaurants</h2>
            <Row xs={1} md={2} lg={3} className="g-4">
                {restaurants.map((restaurant, index) => (
                    <Col key={index}>
                        <Card className="custom-card" onClick={() => handleRestaurantClick(restaurant.RestaurantID)}>
                            <Card.Body>
                                <Card.Title className="text-primary">{restaurant.RestaurantName}</Card.Title>
                                <Card.Text><strong>Contact No:</strong> {restaurant.RestaurantContactNo}</Card.Text>
                                <Card.Text><strong>Address:</strong> {restaurant.RestaurantStreet}, {restaurant.RestaurantCity}, {restaurant.RestaurantState} - {restaurant.RestaurantZipCode}</Card.Text>
                                <Card.Text><strong>Type:</strong> {restaurant.RestaurantType}</Card.Text>
                                <Card.Text><strong>Is Open:</strong> {restaurant.IsOpen}</Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    );
};

export default Restaurant;
