import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import axios from 'axios'

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [isEmailValid, setIsEmailValid] = useState(true);
  const [isPasswordValid, setIsPasswordValid] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoginValid, setIsLoginValid] = useState(true);

  const navigate = useNavigate();
  const [user, setUser] = useState(null);

 

  const validateEmail = (email) => {
  //   // Perform email validation logic (e.g., basic format check)
  //   // Return true if email is valid, false otherwise
    return /\S+@\S+\.\S+/.test(email);
  };
  const handleEmailChange = (e) => {
    setIsEmailValid(true);
    const inputEmail = e.target.value;
    setEmail(inputEmail);
    
  };
   const handlePasswordChange = (e) => {
  setIsPasswordValid(true);
   const inputPassword = e.target.value;
    setPassword(inputPassword);
    
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    setIsEmailValid(validateEmail(email));
    setIsPasswordValid(!!password);
    
    if (isEmailValid && isPasswordValid) {
        try {
            const response = await axios.post("http://localhost:3000/api/users/login", { email, password });
            const data = response.data;

            if (data.success) {
                const customerId = data.userId;
                navigate(`/restaurant/${customerId}`); // Navigate to restaurant page with customer ID in the URL
            } else {
                console.log("Login failed: ", data.message);
                // Handle login failure
            }
        } catch (error) {
            console.error("Error during login:", error);
            alert("An error occurred during login.");
        }
    } else {
        // Display an error message or prevent form submission
    }

    setIsLoading(false);
};


 


  return (
    <div className="login-container">
      <div className="container d-flex align-items-center justify-content-center vh-100">
        <div className="card p-4 login-card">
          <h1 className="card-title text-center mb-4">Login</h1>
          {!isLoginValid && (
            <h4 className="text-center text-danger">Invalid Credentials!</h4>
          )}
          <form>
            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                Email address<span style={{ color: "red" }}>*</span>
              </label>
              <input
                type="email"
                className="form-control"
                id="email"
                placeholder="Enter email"
                value={email}
                onChange={handleEmailChange}
              />
              {!isEmailValid && (
                <p className="text-danger">Invalid email format</p>
              )}
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
                Password<span style={{ color: "red" }}>*</span>
              </label>
              <input
                type="password"
                className="form-control"
                id="password"
                placeholder="Enter password"
                value={password}
                onChange={handlePasswordChange}
              />
              {!isPasswordValid && (
                <p className="text-danger">Password field is mandatory!</p>
              )}
            </div>
            <button
              type="submit"
              className="btn btn-success w-100 mb-3"
              onClick={(e) => handleSubmit(e)}
            >
              {isLoading ? (
                <div className="spinner-border" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              ) : (
                "Login"
              )}
            </button>
           
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
